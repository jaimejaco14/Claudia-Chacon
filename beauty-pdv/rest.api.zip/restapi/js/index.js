jQuery(document).ready(function ($) {
  document
    .getElementById("select-date")
    .addEventListener("change", function () {
      valor_hour_cita = this.value
      fechaTurno(valor_hour_cita)
    })

  document.getElementById("salon-list").addEventListener("click", function () {
    salon_id = this.value
  })

  document
    .getElementById("document-client")
    .addEventListener("input", function () {
      let valorIngresado = document.getElementById("document-client").value

      if (valorIngresado.length > 4) {
        $("#client-list").html("")
        obtenerClient(valorIngresado)
      } else {
        $("#client-list").html("")
      }
    })
  function obtenerClient(cedula) {
    $.ajax({
      type: "GET",
      url: "https://claudiachacon.com/beauty/beauty-pdv/restapi/items/cliente.php",
      data: { documento: cedula },
      success: function (data) {
        for (let i = 0; i < data.length; i++) {
          $("#client-list").append(
            "<option style='cursor:pointer' value='" +
              data[i].documento +
              "' onclick='guardarNombre(\"" +
              data[i].razonsocial +
              "\")'>" +
              data[i].razonsocial +
              "</option>"
          )
        }
      },
    })
  }
})

function guardarNombre(nombre) {
  document.querySelector("#client-list").innerHTML = ""
  document.getElementById("name-client").innerHTML = nombre
}

function servicios(colaboradores) {
  xhr = new XMLHttpRequest()
  xhr.open(
    "GET",
    "https://claudiachacon.com/beauty/beauty-pdv/restapi/items/servicios.php?colaborador_id=" +
      colaboradores +
      ""
  )
  xhr.send()
  xhr.responseType = "json"
  xhr.onload = () => {
    if (xhr.readyState == 4 && xhr.status == 200) {
      const data = xhr.response
      console.log(data)
      document.querySelector("#services-list").innerHTML = ""

      for (let i = 1; i < data.length; i++) {
        document.querySelector("#services-list").innerHTML +=
          "<option style='cursor:pointer' value=" +
          data[i].servicio_id +
          ">" +
          data[i].nombre_servicio +
          "</option>"
      }
    } else {
    }
  }
}
function colaboradores(id) {
  xhr = new XMLHttpRequest()
  xhr.open(
    "GET",
    "https://claudiachacon.com/beauty/beauty-pdv/restapi/items/colaboradores.php?salon_id=" +
      id +
      ""
  )
  xhr.send()
  xhr.responseType = "json"
  xhr.onload = () => {
    if (xhr.readyState == 4 && xhr.status == 200) {
      const data = xhr.response

      const id_colaborador = []

      for (let i = 0; i < data.length; i++) {
        id_colaborador.push(data[i].colaborador_id)
      }

      servicios(id_colaborador)
    } else {
    }
  }
}
function horasMenu(horaInicial, horaFinal, intervalo, dia) {
  let minHora = horaInicial.split(":", 3)
  let maxHora = horaFinal.split(":", 3)
  let minHoraMin = Number(minHora[1])
  let maxHoraMin = Number(maxHora[1])

  var minutos

  if (maxHoraMin === 0) minutos = 1
  else minutos = 30

  let minHoraNum = Number(minHora[0])
  let maxHoraNum = Number(maxHora[0])

  let select = document.createElement("select")

  document.querySelector("#hour_salon").innerHTML = ""

  for (let i = minHoraNum; i <= maxHoraNum; i++) {
    if (minHoraMin === 0) {
      document.querySelector("#hour_salon").innerHTML +=
        "<option style='cursor:pointer' value='" +
        i +
        ":00:00'>" +
        i +
        ":00:00</option>"
      minHoraMin = 30
    } else {
      document.querySelector("#hour_salon").innerHTML +=
        "<option style='cursor:pointer' value='" +
        i +
        ":30:00'>" +
        i +
        ":30:00</option>"
      minHoraMin = 0
    }
  }

  return select
}

function getHorasOcupadas(params, horaInicial, horaFinal) {
  let day = params.fecha_cita.getDate()
  let month = params.fecha_cita.getMonth() + 1
  let year = params.fecha_cita.getFullYear()
  const newDate = `${year}-${month}-${day}`
  console.log("getHorasOcupadas", {
    salon_id: parseInt(params.salon_id),
    fecha_cita: newDate,
  })

  const xhr = new XMLHttpRequest()

  xhr.open(
    "POST",
    "https://claudiachacon.com/beauty/beauty-pdv/restapi/items/disponibilidad.php"
  )

  xhr.setRequestHeader("Content-type", "application/json")
 // xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
 // xhr.setRequestHeader("Access-Control-Allow-Origin", "*")

  xhr.send(
    JSON.stringify({
      salon_id: params.salon_id,
      fecha_cita: newDate,
    })
  )

  xhr.responseType = "json"

  xhr.onload = () => {
    console.log("xhr.onload", xhr.response)
  }
}

function intervaloHoras(horas, horaInicial, horaFinal) {
  const horaIni = horaInicial.split(":")
  const horaFin = horaFinal.split(":")

  let seg = "00"
  let hora = parseInt(horaIni[0])
  let min = parseInt(horaIni[1])
  const finHora = parseInt(horaFin[0])
  const finMin = parseInt(horaFin[1])
  const finSeg = parseInt(horaFin[2])
  let intervalo = [
    {
      value: "",
      text: "",
    },
  ]
  if (finMin == 0 && finSeg == 0) {
    while (hora <= finHora) {
      //intervalo.push(`${hora}:00:00`);
      intervalo.push({ value: `${hora}:00:00`, text: `${hora}:00:00` })
      hora++
    }
  } else {
    while (hora < finHora || min < finMin || seg < finSeg) {
      //intervalo.push(`${hora}:${min < 10 ? '0'+ min : min}:${0 < 10 ? '0' + 0 : 0}`);
      intervalo.push({
        value: `${hora}:${min < 10 ? "0" + min : min}:${0 < 10 ? "0" + 0 : 0}`,
        text: `${hora}:${min < 10 ? "0" + min : min}:${0 < 10 ? "0" + 0 : 0}`,
      })
      min += 30
      if (min > 59) {
        hora++
        min = 0
      }
      seg = 0
    }
  }
  intervalo.push({ value: horaFinal, text: horaFinal })

  document.querySelector("#hour_salon").innerHTML = ""

  for (let i = 1; i < intervalo.length; i++) {
    document.querySelector("#hour_salon").innerHTML +=
      "<option style='cursor:pointer' value=" +
      intervalo[i].value +
      ">" +
      intervalo[i].text +
      "</option>"
  }
  intervalo = []
  return intervalo
}

function fechaTurno(fecha) {
  var fecha = new Date(fecha)
  var diasSemana = [
    "LUNES",
    "MARTES",
    "MIERCOLES",
    "JUEVES",
    "VIERNES",
    "SABADO",
    "DOMINGO",
  ]
  var diaActual = diasSemana[fecha.getDay()]

  const xhr = new XMLHttpRequest()

  xhr.open(
    "GET",
    "https://claudiachacon.com/beauty/beauty-pdv/restapi/items/turnos.php?salon_id=" +
      salon_id +
      ""
  )
  xhr.send()
  xhr.responseType = "json"
  xhr.onload = () => {
    if (xhr.readyState == 4 && xhr.status == 200) {
      const data = xhr.response
      for (let i = 0; i < data.length; i++) {
        if (data[i].dia == diaActual) {
          getHorasOcupadas(
            { fecha_cita: fecha, salon_id },
            data[i].desde,
            data[i].hasta
          )
        }
      }
    } else {
    }
  }
  return diaActual
}

function salones() {
  const xhr = new XMLHttpRequest()

  xhr.open(
    "GET",
    "https://claudiachacon.com/beauty/beauty-pdv/restapi/items/salones.php"
  )
  xhr.send()
  xhr.responseType = "json"
  xhr.onload = () => {
    if (xhr.readyState == 4 && xhr.status == 200) {
      const data = xhr.response
      for (let i = 0; i < data.length; i++) {
        document.querySelector("#salon-list").innerHTML +=
          "<option style='cursor:pointer' onclick='colaboradores(\"" +
          data[i].salon_id +
          "\")' value='" +
          data[i].salon_id +
          "'>" +
          data[i].nombre_salon +
          "</option>"
      }
    } else {
    }
  }
}

salones()

