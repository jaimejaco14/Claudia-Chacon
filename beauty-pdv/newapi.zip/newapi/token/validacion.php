<?php

function VerificarToken($token,$validTokens){
    if (in_array($token, $validTokens)) {
        // El token es válido, permita que el usuario acceda a los recursos solicitados
    } else {
        // El token no es válido, devuelva un error de autenticación
        http_response_code(401);
        echo "Error de autenticación: Token inválido";
        exit();
    }
}
