<?php
class Items{ 

    public $sercodigo;
    public $slncodigo;
    public $citfecha;
    public $cithora;
    public $documento;
    public $clbcodigo;

    private $conn;
	
    public function __construct($db){
        $this->conn = $db;
    }	
	
    
	function disponibilidad(){	
		try{

            $servicio = $this->sercodigo;
            $salon = $this->slncodigo;
            $fecha = $this->citfecha;
            $hora = $this->cithora;

			$stmt = $this->conn->prepare("SELECT DISTINCT c.clbcodigo, svc.sercodigo, svc.sernombre, svc.trcrazonsocial, slncodigo
            FROM btycolaborador c
            INNER JOIN bty_vw_servicios_colaborador svc ON c.clbcodigo = svc.clbcodigo
            INNER JOIN btyservicio s ON svc.sercodigo = s.sercodigo
            LEFT JOIN btysalon_base_colaborador sbc ON c.clbcodigo = sbc.clbcodigo
            WHERE svc.sercodigo = $servicio AND slncodigo = $salon
            AND c.clbcodigo NOT IN (SELECT DISTINCT clbcodigo FROM btycita WHERE citfecha = $fecha AND cithora = $hora AND c.clbcodigo = clbcodigo)
            ORDER BY c.clbcodigo
            ");
            $stmt->execute();			
            $result = $stmt->get_result();		
            return $result;	
		}catch(Exception $e){
            http_response_code(400);     
            echo json_encode('not found');
        }
	}

    function cliente(){	
        try{
            $documento = $this->documento;
            $stmt = $this->conn->prepare("SELECT * FROM btycliente INNER JOIN btytercero ON btycliente.trcdocumento = btytercero.trcdocumento WHERE btycliente.trcdocumento = ".strval($documento)."");
            $stmt->execute();			
            $result = $stmt->get_result();		
            return $result;
        }catch(Exception $e){
            http_response_code(400);     
            echo json_encode('not found');
        }

	}

    function turno_salon(){	
		if($this->slncodigo) {

			$id_salon = $this->slncodigo;

			$stmt = $this->conn->prepare("SELECT * FROM btyhorario_salon INNER JOIN btyhorario ON btyhorario_salon.horcodigo =btyhorario.horcodigo WHERE btyhorario_salon.slncodigo = ".strval($id_salon)."");

		} else {
			http_response_code(400);     
			echo json_encode('not found');
		}		
		$stmt->execute();			
		$result = $stmt->get_result();		
		return $result;	
	}
    function salones(){	
		try {
			$stmt = $this->conn->prepare("SELECT * FROM btysalon");
			$stmt->execute();			
			$result = $stmt->get_result();		
			return $result;	
		} catch (Exception $e) {
			echo 'Error: ',  $e->getMessage(), "\n";
		}			
		return $result;	
	}
    function servicios_colaboradores(){	
		if($this->clbcodigo) {

            $clbcodigo = $this->clbcodigo;
			$stmt = $this->conn->prepare("SELECT DISTINCT sernombre, sercodigo, clbcodigo FROM bty_vw_servicios_colaborador WHERE clbcodigo IN (".$clbcodigo.")");	

		} else {
			http_response_code(400);     
			echo json_encode('not found');
		}		
		
		$stmt->execute();			
		$result = $stmt->get_result();	
		return $result;
	}
}