<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/Database.php';
include_once '../class/Items.php';

$database = new Database();
$db = $database->getConnection();
 
$items = new Items($db);


$request_body = file_get_contents('php://input');

$data = json_decode($request_body, true);

$result = $items->crearCliente($data);

if($result == 1){    
    $itemRecords["cliente"]=array(); 
        $itemDetails=array(
            "res" => "OK",
            "message" => "cliente creado",
        ); 
       array_push($itemRecords["cliente"], $itemDetails);
     
    http_response_code(200);   
    

    $values = array_values($itemRecords["cliente"]);
  
    echo json_encode($values);
    
}else{     
    http_response_code(404);     
    echo json_encode(
        array("message" => "No item found.")
    );
} 
?>